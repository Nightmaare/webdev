import React from 'react';
import './App.css';

class App extends React.Component {
  state = {
    page : 'Abo'
  }

  render(){
    return (
      <div className="App">
        
      </div>
    );
  }
}

export default App;
