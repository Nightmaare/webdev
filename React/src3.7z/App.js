import React from 'react';
import logo, { ReactComponent } from './logo.svg';
import './App.css';
import Carte from './Carte.js'

class App extends React.Component {


  render(){
    let utils = [
      {
        nbr: 78,
        nom: "Moujib",
        filiere: "Isil"
      },
      {
        nbr: 50,
        nom: "Safi",
        filiere: "Isil"
      },
      {
        nbr: 90,
        nom: "Ourahou",
        filiere: "Isil"
      },
      {
        nbr: 190,
        nom: "Sadik",
        filiere: "Isil"
      }
    ];

    return (
      <div className="App">
        <div className="flex-container">
          <div> <Carte nbr = {utils[0].nbr} nom = {utils[0].nom} filiere = {utils[0].filiere}></Carte> </div>
          <div> <Carte nbr = {utils[1].nbr} nom = {utils[1].nom} filiere = {utils[1].filiere}></Carte> </div>
          <div> <Carte nbr = {utils[2].nbr} nom = {utils[2].nom} filiere = {utils[2].filiere}></Carte> </div>
          <div> <Carte nbr = {utils[3].nbr} nom = {utils[3].nom} filiere = {utils[3].filiere}></Carte> </div>
        </div>
      </div>
    )
  }
}

export default App;
