const {createElement} = React;
const {render} = ReactDOM;



const app1 = createElement(
	'h1',
	{id: 'titre', className:'header'},
	'Bonjour!!'
	);

	const app2 = createElement(
		'p',
		'Bonjour!!'
		);
render(app1, document.getElementById('root'));